const $=id=>document.getElementById(id);
let selectedImage=null;
$('photo').addEventListener('change',e=>{
  const file=e.target.files[0]; if(!file)return;
  if(!file.type.startsWith('image/'))return;
  selectedImage=file;
  $('preview').src=URL.createObjectURL(file);
  $('previewWrap').classList.remove('hidden');$('clearPhoto').classList.remove('hidden');
});
$('clearPhoto').addEventListener('click',()=>{
  selectedImage=null;$('photo').value='';$('preview').removeAttribute('src');
  $('previewWrap').classList.add('hidden');$('clearPhoto').classList.add('hidden');
});
$('solveBtn').addEventListener('click',()=>{
  const age=$('age').value,stage=$('stage').value,subject=$('subject').value,q=$('question').value.trim();
  if(!age||!stage||!subject){$('status').textContent='من فضلك أكمل السن والمرحلة والمادة أولاً.';return;}
  if(!q&&!selectedImage){$('status').textContent='اكتب السؤال أو ارفع صورة له أولاً.';return;}
  $('status').textContent='تم تجهيز بيانات السؤال. محرك الذكاء الاصطناعي يحتاج إلى ربط خدمة إجابات قبل تقديم حل حقيقي.';
});
let deferredPrompt;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;$('installBtn').classList.remove('hidden')});
$('installBtn').addEventListener('click',async()=>{
  if(!deferredPrompt)return;
  deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$('installBtn').classList.add('hidden');
});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));